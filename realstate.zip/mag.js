﻿//---------- cats
var MGcatsdb = new Array();
function mgCat(id, name, parent) {
    this.id = id;
    this.name = name;
    this.parent = parent;
}
function MGgetCats() {
    showWait(21);
    socket.emit('MGgetCats', { dmyskid: myskid })
}
function MGinjectCats(db) {
    hideWait();
    MGcatsdb = new Array();
    var tar = db.split('nnpp');
    for (var h = 0; h <= tar.length - 1; h++) {
        if (tar[h].length > 3) {
            var tar2 = tar[h].split(',');
            var nc = new mgCat(tar2[0], tar2[1], tar2[2]);
            MGcatsdb[MGcatsdb.length] = nc;
        }
    }
    ////console.log(MGcatsdb.length + " <= cats len");
    MGgetTags();
}
//---------- tags
var MGtagsdb = new Array();
function mgTag(id, name, cont) {
    this.id = id;
    this.name = name;
    this.cont = cont;
}
function MGgetTags() {
    showWait(22);
    socket.emit('MGgetTags', { dmyskid: myskid })
}
function MGinjectTags(db) {
    hideWait();
    MGtagsdb = new Array();
    var tar = db.split('nnpp');
    for (var h = 0; h <= tar.length - 1; h++) {
        if (tar[h].trim().length > 0) {
            var tar2 = tar[h].split(',');
            var nc = new mgTag(tar2[0], tar2[1], tar2[2]);
            MGtagsdb[MGtagsdb.length] = nc;
        }
    }

    for (var i = 0; i <= MGtagsdb.length - 1; i++) {
        for (var j = i+1; j <= MGtagsdb.length - 1; j++) {
            if (MGtagsdb[j].cont > MGtagsdb[i].cont) {
                var tmp = MGtagsdb[i];
                MGtagsdb[i] = MGtagsdb[j];
                MGtagsdb[j] = tmp;
            }
        }
    }
    for (var i = 0; i <= 30; i++) {
        var nel = '<li><a onclick="getListTag(\'' + MGtagsdb[i].name + '\');" href="#">' + MGtagsdb[i].name + '</a></li>';
        jQuery('#tagsul').append(jQuery(nel));
		jQuery('#tagsul2').append(jQuery(nel));
		jQuery('#tagsul3').append(jQuery(nel));
    }
    ////console.log(MGtagsdb.length + " <= tags len");
    MGgetRiters();
}

//---------- riters
var MGritersdb = new Array();
function mgRiter(id, name) {
    this.id = id;
    this.name = name;
}
function MGgetRiters() {
    showWait(25);
    socket.emit('MGgetRiters', { dmyskid: myskid })
}
function MGinjectRiter(db) {
    hideWait();
    ////console.log("writer: " + db);
    MGritersdb = new Array();
    var tar = db.split('nnpp');
    for (var h = 0; h <= tar.length - 1; h++) {
        if (tar[h].length > 3) {
            var tar2 = tar[h].split(',');
            var nc = new mgRiter(tar2[0].trim(), tar2[1]);
            MGritersdb[MGritersdb.length] = nc;
        }
    }
    ////console.log(MGritersdb.length + " <= riter len");
    MGgetHomePosts();
}


//---------- Vitrin Posts ------------
var MGvitrindb = new Array();
function mgPost1(id, titr, stx, dat, cat, person, fimg ) {
    this.id = id;
    this.titr = titr;
    this.stx = stx;
    this.dat = dat;
    this.cat = cat;
    this.person = person;
    this.fimg = fimg;
}
function MGgetVitrin() {
    showWait(23);
    socket.emit('MGgetVitrin', { dmyskid: myskid });
}
function MGinjectVitrin(db) {
    hideWait();
    MGtagsdb = new Array();
    var tar = db.split('nnpp');
    for (var h = 0; h <= tar.length - 1; h++) {
        if (tar[h].trim().length > 0) {
            var tar2 = tar[h].split(',');
            var nc = new mgTag(tar2[0], tar2[1], tar2[2]);
            MGtagsdb[MGtagsdb.length] = nc;
        }
    }
    //console.log(MGtagsdb.length + " <= tags len");
}
//---------------- setfimg
function MGsetFImg() {
    showWait(23);
    socket.emit('MGsetfimg', { dmyskid: myskid })
}
//----------- home posts

var MGhomdb = new Array();
function dpost(id,part,tit,img1,stx,dat,riter){
    this.id = id;
    this.part = part;
    this.tit = tit;
    this.img1 = img1;
    this.stx = stx;
    this.dat = dat;
    this.riter = riter;
}
function MGgetHomePosts() {
    showWait(24);
    socket.emit('MGgetHomePosts', { dmyskid: myskid });
}
function getprevfrom(ppt) {
    ////console.log(ppt.split("\n").length);
    return ppt.split("\n")[0];
    //jQuery(MGhomdb[h].stx).text().substring(0, 150) + " ...";
}
function MGinjectHomePost(db) {
    //hideWait();
    console.log("db is: "+db);
    MGhomdb = JSON.parse(db);
    ////console.log("db len:: " + MGhomdb.length);

    jQuery('#adsswiperholder .swiper-slide').remove();
    jQuery('#vitposts1').empty();
    jQuery('#vitposts2').empty();
    jQuery('#tab1row').empty();
    jQuery('#tab2row').empty();
    jQuery('#tab3row').empty();
    jQuery('#tab4row').empty();
    jQuery('#tab5row').empty();
    jQuery('#itmlist6').empty();
    jQuery('#itmlist7').empty();
	jQuery('#itmlist72').empty();
    jQuery('#itmlist8').empty();

    var vit_pc = 0;

    for (var h = 0; h <= MGhomdb.length - 1; h++) {
        //MGhomdb[h].img1=
		
        try{
		MGhomdb[h].img1=MGhomdb[h].img1.split(',')[0];
		}catch(ex){
		try{
		if (isNullOrWhitespace(MGhomdb[h].img1) == true) {
            MGhomdb[h].img1 = "noimage.png";
        }
		
		}catch(ex2){
		//MGhomdb[h].img1 = "noimage.png";	
		}
		}
		//var hi=MGhomdb[h].img1[];
		//console.log(hi.split(',').length);
        switch (MGhomdb[h].part) {
            case "conf":
                //$nc ->part="conf";
                //$nc ->tit=$rec ->dieName;
                //$nc ->val=$rec ->dieVal;

                switch (MGhomdb[h].tit) {
                    case "lbl_sabkzendegi":
                        jQuery('#lbl_sabkzendegi').text(MGhomdb[h].val);
                        break;
                    case "lbl_jadidtandorosti":
                        jQuery('#lbl_jadidtandorosti').text(MGhomdb[h].val);
						jQuery('#lbl_jadidtandorosti2').text(MGhomdb[h].val);
                        break;
                    case "lbl_videobartar":
                        jQuery('#lbl_videobartar').text(MGhomdb[h].val);
                        break;
                    case "lbl_modjadid":
                        jQuery('#lbl_modjadid').text(MGhomdb[h].val);
                        break;
                    case "lbl_deltaapp":
                        jQuery('#lbl_deltaapp').text(MGhomdb[h].val);
						jQuery('#lbl_deltaapp2').text(MGhomdb[h].val);
						jQuery('#lbl_deltaapp3').text(MGhomdb[h].val);
                        break;
                    case "lbl_deltamag":
                        jQuery('#lbl_deltamag').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_1':
                        jQuery('#conf1').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_2':
                        jQuery('#conf2').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_3':
                        jQuery('#conf3').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_4':
                        jQuery('#conf4').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_5':
                        jQuery('#conf5').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_6':
                        jQuery('#conf6').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_7':
                        jQuery('#conf7').text(MGhomdb[h].val);
                        break;
                    case 'opt_subcat_8':
                        jQuery('#conf8').text(MGhomdb[h].val);
                        break;

                    default:
                       // # code...
                        break;
                }
                break;
            case "ads":
                var nelh = '<div class="swiper-slide"><a href="#"><img src="' + MGhomdb[h].img1 + '" alt=""></a></div>';
                jQuery('#adsswiperholder').append(jQuery(nelh));
				jQuery('#adsswiperholder2').append(jQuery(nelh));
				jQuery('#adsswiperholder3').append(jQuery(nelh));
                break;
            case "vit":
                ////console.log("vit: " + MGhomdb[h].tit);
                if (vit_pc > 2) {
                    var nelh = '<div class="swiper-slide">';
                    nelh += '<div class="boxIntro">';
                    nelh += '<div class="imgCadr">';
                    nelh += '<div style= "background-image:url(' + MGhomdb[h].img1 + ')" class="card-header">';
                    nelh += '</div>';
                    nelh += '</div>';
                    nelh += '<div class="card-content card-content-padding">';
                    var tx2 = getprevfrom(MGhomdb[h].stx);//jQuery(MGhomdb[h].stx).text().substring(0, 150) + " ...";
                    nelh += '<h2>' + MGhomdb[h].tit + '</h2>';
                    nelh += '<p>' + tx2 + '</p>';
                    nelh += '<div class="footer">';
                    //nelh += '<time><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                    nelh += '<a onclick="showpost(' + MGhomdb[h].id + ');" href="#">ادامه مطلب</a>';
                    nelh += '</div>';
                    nelh += '</div>';
                    nelh += '</div>';
                    nelh += '</div>';
                    jQuery('#vitposts1').append(jQuery(nelh));
                    vit_pc++;
                } else {
                    var nelh = '<li>';
                    nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">';
                    nelh += '<img src="' + MGhomdb[h].img1 + '" alt="' + MGhomdb[h].tit + '">';
                    nelh += '</a>';
                    nelh += '<div class="autor">';
                    nelh += '<i class="fa fa-pencil" aria-hidden="true"></i><a href="#" class="">رضا عدالت</a></div>';
                    nelh += '<h3><a href="#" onclick="showpost(' + MGhomdb[h].id + ');">' + MGhomdb[h].tit + '</a></h3>';
                    nelh += '</li>';
                    jQuery('#vitposts2').append(jQuery(nelh));
                    vit_pc++;

                }
                break;
            case "opt_subcat_1":
                var nelh = '<div class="tablet-30 col-50">';
                nelh += '<article class="listbox">';
                nelh += '<div style="background-image:url(' + MGhomdb[h].img1 + ')" class="card-header"></div>';
                nelh += '<div class="card-content card-content-padding">';
                nelh += '<div class="desc">';
                nelh += '<h2>' + MGhomdb[h].tit + '</h2>';
                //console.log(MGhomdb[h].stx);
                var tx2 = getprevfrom(MGhomdb[h].stx);// jQuery(MGhomdb[h].stx).text().substring(0, 20) + " ...";
                nelh += '<p>' + tx2 + '</p>';
                nelh += '</div>';
                nelh += '<div class="footer">';
                nelh += '<time><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">ادامه مطلب</a>';
                nelh += '</div></div></article></div>';

                jQuery('#tab1row').append(jQuery(nelh));
                break;
            case "opt_subcat_2":
                var nelh = '<div class="tablet-30 col-50">';
                nelh += '<article class="listbox">';
                nelh += '<div style="background-image:url(' + MGhomdb[h].img1 + ')" class="card-header"></div>';
                nelh += '<div class="card-content card-content-padding">';
                nelh += '<div class="desc">';
                nelh += '<h2>' + MGhomdb[h].tit + '</h2>';
                var tx2 = getprevfrom(MGhomdb[h].stx);//jQuery(MGhomdb[h].stx).text().substring(0, 150) + " ...";
                //nelh += '<p>' + tx2 + '</p>';
                nelh += '</div>';
                nelh += '<div class="footer">';
                nelh += '<time><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">ادامه مطلب</a>';
                nelh += '</div></div></article></div>';

                jQuery('#tab2row').append(jQuery(nelh));
                break;
            case "opt_subcat_3":
                var nelh = '<div class="tablet-30 col-50">';
                nelh += '<article class="listbox">';
                nelh += '<div style="background-image:url(' + MGhomdb[h].img1 + ')" class="card-header"></div>';
                nelh += '<div class="card-content card-content-padding">';
                nelh += '<div class="desc">';
                nelh += '<h2>' + MGhomdb[h].tit + '</h2>';
                var tx2 = getprevfrom(MGhomdb[h].stx);//jQuery(MGhomdb[h].stx).text().substring(0, 150) + " ...";
                //nelh += '<p>' + tx2 + '</p>';
                nelh += '</div>';
                nelh += '<div class="footer">';
                nelh += '<time><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">ادامه مطلب</a>';
                nelh += '</div></div></article></div>';

                jQuery('#tab3row').append(jQuery(nelh));
                break;
            case "opt_subcat_4":
                var nelh = '<div class="tablet-30 col-50">';
                nelh += '<article class="listbox">';
                nelh += '<div style="background-image:url(' + MGhomdb[h].img1 + ')" class="card-header"></div>';
                nelh += '<div class="card-content card-content-padding">';
                nelh += '<div class="desc">';
                nelh += '<h2>' + MGhomdb[h].tit + '</h2>';
                var tx2 = getprevfrom(MGhomdb[h].stx);//jQuery(MGhomdb[h].stx).text().substring(0, 150) + " ...";
                //nelh += '<p>' + tx2 + '</p>';
                nelh += '</div>';
                nelh += '<div class="footer">';
                nelh += '<time><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">ادامه مطلب</a>';
                nelh += '</div></div></article></div>';

                jQuery('#tab4row').append(jQuery(nelh));
                break;
            case "opt_subcat_5":
                var nelh = '<div class="tablet-30 col-50">';
                nelh += '<article class="listbox">';
                nelh += '<div style="background-image:url(' + MGhomdb[h].img1 + ')" class="card-header"></div>';
                nelh += '<div class="card-content card-content-padding">';
                nelh += '<div class="desc">';
                nelh += '<h2>' + MGhomdb[h].tit + '</h2>';
                var tx2 = getprevfrom(MGhomdb[h].stx);//jQuery(MGhomdb[h].stx).text().substring(0,20)+" ...";
                //nelh += '<p>' + tx2 + '</p>';
                ////console.log("stx5:: " + tx2);
                nelh += '</div>';
                nelh += '<div class="footer">';
                nelh += '<time><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">ادامه مطلب</a>';
                nelh += '</div></div></article></div>';

                jQuery('#tab5row').append(jQuery(nelh));
                break;
            case "opt_subcat_6":
                var nelh = '<li>';
                nelh += '<h2>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">' + MGhomdb[h].tit + '</a>';
                nelh += '</h2>';
                nelh += '<div>';
                nelh += '<time class=""><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat +'</time>';
                nelh += '<div class="autor">';
                nelh += '<i class="fa fa-pencil" aria-hidden="true"></i>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">' + MGhomdb[h].riter + '</a>';
                nelh += '</div>';
                nelh += '</div>';
                nelh += '</li>';
                jQuery('#itmlist6').append(jQuery(nelh));
				jQuery('#itmlist62').append(jQuery(nelh));
                break;
            case "opt_subcat_7":
                var nelh = '<div class="vidbox tablet-25 col-50">';
                nelh += '<a href="#" class="imgperv" onclick="showpost(' + MGhomdb[h].id + ');">';
                nelh += '<img src="' + MGhomdb[h].img1 + '" />';
                nelh += '</a>';
                nelh += '<div class="desc">'
                nelh += '<h3><a href="#">' + MGhomdb[h].tit + '</a></h3>';
                nelh += '<time class=""><i class="fa fa-calendar" aria-hidden="true"></i>' + MGhomdb[h].dat + '</time>';
                nelh += '<div class="autor">';
                nelh += '<i class="fa fa-user" aria-hidden="true"></i>';
                nelh += '<a href="#" onclick="showpost(' + MGhomdb[h].id + ');">' + MGhomdb[h].riter + '</a>';
                nelh += '</div>';
                nelh += '</div>';
                nelh += '</div>';
                jQuery('#itmlist7').append(jQuery(nelh));
				jQuery('#itmlist72').append(jQuery(nelh));
                break;
            case "opt_subcat_8":
                var nelh = '<div onclick="showpost(' + MGhomdb[h].id + ');" class="swiper-slide" style="background-image:url(' + MGhomdb[h].img1 + ')"></div>';
                jQuery('#itmlist8').append(jQuery(nelh));
                break;
        }
        ////console.log("write: " + MGhomdb[h].riter);
    }
    ////console.log(MGhomdb.length + " <= vitrin posts len");

    //---------- get box tits ----



    showMag();
    //pagingSwiper
    //magSwiper
    var asdSwiper = new Swiper('.adsSwiper', {
        direction: 'vertical',
        slidesPerView: 3,
        spaceBetween: 20,
        //effect: 'flip',
        //effect: 'coverflow',
        grabCursor: true,
        loop: false,
        freeMode: true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
    var magSwiper1 = new Swiper('.slide1', {
        spaceBetween: 0,
        centeredSlides: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
}

//----------- loadMag
function loadMag() {
    MGgetCats();
}
function showMag() {
    hideWait();
    //console.log("***** u ar in mag....");
    go2('p20');

	jQuery('#dienavbar21').html( jQuery('#dienavbar20').html());
	jQuery('#dienavbar22').html( jQuery('#dienavbar20').html());


}

//------------go to home search
function go2filesearch() {
    if (getoff('firsttime') == 'y') {
        if (getoff('lastcity') == null) {
            go2('p2');
        } else {
            actifCity = getoff('lastcity');
            setActifCity(actifCity);
            go2('p3');
        }
    } else {
        go2('p2');
    }
}
function go2mag() {
    loadMag();
}

//-------
var listPostDB = new Array();
var listPostTit = "";

function getListCat(cn) {
    listPostTit = cn;
    showWait(27);
    socket.emit('MGgetListCat', { dtit: cn });
}
function getListTag(cn) {
    listPostTit = cn;
    showWait(28);
    socket.emit('MGgetListTag', { dtit: cn });
}
function MGinjectListPost(db) {
    jQuery('#listtit').text(listPostTit);
    //console.log("db is : " + db);
    listPostDB = JSON.parse(db);
    console.log(listPostDB.length + " post catch ....");
    jQuery('#listpslider').empty();
    for (var k = 0; k <= listPostDB.length - 1; k++) {
        if (listPostDB[k].id == undefined) { continue; }
        var nel = '<div class="swiper-slide">';
        nel += '<div class="card-col">';
        nel += '<article>';
        nel += '<div style="background-image:url(' + listPostDB[k].img1 + ')" class="card-header"></div>';
        nel += '<div class="card-content card-content-padding">';
        nel += '<p>' + listPostDB[k].tit + '</p>';
        nel += '<div class="footer">';
        nel += '<time><i class="fa fa-calendar" aria-hidden="true"></i>97/10/1</time>';
        nel += '<a href="" onclick="showpost(' + listPostDB[k].id + ')" class="">ادامه مطلب</a>';
        nel += '</div>';
        nel += '</div>';
        nel += '</article>';
        nel += '</div></div>';
        jQuery('#listpslider').append(jQuery(nel));
    }
    MGloadquestions();
    go2('p21');

    var pagingSwiper = new Swiper('.pagingSwiper', {
        slidesPerView: 2,
        slidesPerColumn: 3,
        spaceBetween: 10,
        slidesPerGroup: 2,
        //effect:'fade',
        breakpoints: {
            640: {
                slidesPerView: 1,
                slidesPerColumn: 3,
                spaceBetween: 10,
                slidesPerGroup: 1,
            }
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            //dynamicBullets: true,
            className: "paging",
            renderBullet: function (index, className) {

                return '<span class="' + className + '">' + (index + 1) + '</span>';
            },
        },
    });
}

//------------

//MGloadquestions
var MGqustionsdb = new Array();
function mgQues(id, quest, answer) {
    this.id = id;
    this.quest = quest;
    this.answer = answer;
}
function MGloadquestions() {
    showWait(25);
    socket.emit('MGloadquestions', { dmyskid: myskid })
}
function MGinjectQuestion(db) {
    hideWait();

    //console.log("writer: " + db);
    //dperson2,dperson1,dans,ddate,dqtit
    MGqustionsdb = new Array();
    MGqustionsdb = JSON.parse(db);
    // var tar = db.split('nnpp');
    //jQuery('#mgfaqdv').empty();
    var el3 = jQuery('#mgfaqdv .accordion-item');

    for (var h = 0; h <= MGqustionsdb.length - 1; h++) {
        //if (tar[h].length > 3) {
        //    var tar2 = tar[h].split(',');
        //    var nc = new mgRiter(tar2[0].trim(), tar2[1]);
        //    MGritersdb[MGritersdb.length] = nc;
        //}


        var el = jQuery(jQuery('#mgfaqdv .accordion-item')[0]).clone();
        jQuery(jQuery(el).find('.MAGqtit')[0]).text(MGqustionsdb[h].dqtit);
        jQuery(jQuery(el).find('.MAGtxt')[0]).text(MGqustionsdb[h].dans);
        jQuery(el).show();
        jQuery('#mgfaqdv').append(jQuery(el));
		el = jQuery(jQuery('#mgfaqdv2 .accordion-item')[0]).clone();
        jQuery(jQuery(el).find('.MAGqtit')[0]).text(MGqustionsdb[h].dqtit);
        jQuery(jQuery(el).find('.MAGtxt')[0]).text(MGqustionsdb[h].dans);
        jQuery(el).show();
        //jQuery('#mgfaqdv').append(jQuery(el));
		jQuery('#mgfaqdv2').append(jQuery(el));

    }

    for (var i = 1; i <= el3.length - 1; i++) {
        jQuery(el3[i]).remove();
    }

    //var el3 = jQuery('#mgfaqdv .accordion-item');
    //for (var i = 1; i <= el3.length - 1; i++) {
    //    jQuery(el3[i]).remove();
    //}

    //console.log(MGritersdb.length + " <= riter len");
    //MGgetHomePosts();
    $('#mgfaqdv > div:nth-child(2)').addClass('accordion-item-opened');
    $('#mgfaqdv2 > div:nth-child(2)').addClass('accordion-item-opened');
}


//---------
var dlatestpstid = "0";
function showpost(id) {
    showWait(31);
    socket.emit('MGloadpost', { did: id });
}
var LATESTpst;
var beardcat = "";
var commentscol;
var tagscol;
var relatepsts;
var likecont = 0;

function unicodeToChar(text) {
    return text.replace(/\\u[\dA-F]{4}/gi,
        function (match) {
            return String.fromCharCode(parseInt(match.replace(/\\u/g, ''), 16));
        });
}
var latestidsretl="";
function MGinjectPost(db) {
    hideWait();
    //console.log("db:: " + db);
    LATESTpst = JSON.parse(db);
    go2('p22');
    //console.log("id == " + dpst.id);
    var cat = LATESTpst[3][0];//LATESTpst[2];//.trim();
    for (var p = 0; p <= MGcatsdb.length - 1; p++) {
        if (MGcatsdb[p].id == cat) {
            beardcat = MGcatsdb[p].name;
        }
    }
    jQuery('#beardcattit').html(beardcat);
    jQuery('#beardcattit').attr("onclick", "getListCat('" + beardcat + "');");
    

    commentscol = LATESTpst[5];
    jQuery('#commentcont').text(commentscol.length);
    //LATESTpst[1].post_content
    jQuery('#psttita2').html(((LATESTpst[1].post_title)));
    jQuery('#psttita1').html(((LATESTpst[1].post_title)));

    //console.log("name: "+LATESTpst[1].post_name);
	var pcont=jQuery(LATESTpst[1].post_content);
	jQuery('#fdvin').empty().append(jQuery(pcont));
	//console.log("p cont = "+jQuery('#fdvin').find('p').length);
	var pl=jQuery('#fdvin').find('p');
	//frsttxt
	jQuery("#blogpostp3").empty().append(jQuery(pcont));//.html(jQuery(jQuery(pl)[0]).html());
	jQuery(jQuery("#blogpostp3").find('p')[0]).addClass('frsttxt');
	//jQuery("#odertxtp").empty();
	//for(var n=1;n<=jQuery(pl).length-1;n++){
	//jQuery("#odertxtp").append(jQuery(pl[n]));
	//}
    tagscol = LATESTpst[7];
    relatepsts = LATESTpst[9];

    likecont = parseInt(LATESTpst[11][0].total);
    if (isNaN(likecont)) { likecont = 0; }
    jQuery('#likecont').text(likecont);

    getshamsi('#pstdate1', LATESTpst[1].post_date);
    //jQuery('#pstdate1').html(((LATESTpst[1].post_date)));

    var autherid = LATESTpst[1].post_author;

    jQuery('#pstriter1').html(((getwritername(autherid).name)));
    //MGritersdb

    jQuery('#psttagsdv a').remove();
    for (var t = 0; t <= tagscol.length - 1; t++) {
        var el1 = '<a href="#" onclick="getListTag(\'' + tagscol[t].name + '\');">' + tagscol[t].name + '</a>';
        //jQuery('#beardcattit').attr("onclick", "getListTag('" + tagscol[t].name + "');");
        jQuery('#psttagsdv').append(jQuery(el1));
    }


    jQuery('#pstrelateditms').empty();
    //relatepsts
    var dates4giv = "";
	var ids4tumb="";
    for (var r = 0; r <= relatepsts.length - 1; r++) {
        var nslid = '<div class="swiper-slide">';
        nslid += '<article class="listbox">';
		ids4tumb+=relatepsts[r].ID+",";
		latestidsretl+=relatepsts[r].ID+",";
        nslid += '<div id="rtpost'+relatepsts[r].ID+'" style="background-image:url(' + relatepsts[r].img1 + ')" class="card-header"></div>';
        nslid += '<div class="card-content card-content-padding">';
        nslid += '<div class="desc">';
        nslid += '<h2><a onclick="showpost(' + relatepsts[r].ID + ')">' + relatepsts[r].post_title + '</a></h2>';
        nslid += '<time><i class="fa fa-calendar" aria-hidden="true"></i><span name="comdt"></span></time>';
        nslid += '</div>';
        nslid += '</div>';
        nslid += '</article>';
        nslid += '</div>';
        jQuery('#pstrelateditms').append(jQuery(nslid));
        dates4giv += relatepsts[r].post_date + "#np#";

    }
	
    //socket.emit('getshamsiseri', { eln: "relatedt", dtstr: dates4giv });
    //getshamsiseri("relatedt", dates4giv);

    if (commentscol.length > 0) {

        var commentsdatestr = "";
        jQuery('#pstcommentsrow').empty();
        for (var i = 0; i <= commentscol.length - 1; i++) {
            if (parseInt(commentscol[i].comment_approved) == 1) {
                var htmstr = '<div class="itmCmd">';
                htmstr += '<label>' + commentscol[i].comment_author + '</label>';
                htmstr += '<time class=""><i class="fa fa-calendar" aria-hidden="true"></i><span name="comdt"></span></time>';
                htmstr += '<p>' + commentscol[i].comment_content + '</p>';
                htmstr += '</div>';

                jQuery('#pstcommentsrow').append(jQuery(htmstr));

                commentsdatestr += commentscol[i].comment_date + "#np#";
            }
        }
        //getshamsiseri("comdt", dates4giv+"#np#"+commentsdatestr);
        
    }

    getshamsiseri("comdt", dates4giv + "#np#" + commentsdatestr);


    myfullname = getoff('myfullname');
    mymobile = getoff('mymobile');
    myemail = getoff('myemail');
    mypass = getoff('mypass');

    if (isNullOrWhitespace(mymobile) == true) {
        mymobile = "";
    } else {
        jQuery("input[name=comentfullnpst]").val(myfullname).addClass('noact');
        jQuery("input[name=comentmailpst]").val(myemail).addClass('noact');
        jQuery("input[name=comentmobpst]").val(mymobile).addClass('noact');
    }
    //commttxa

	getsardabirpost();

	getrelateimages(ids4tumb);
}


function sendcommnt() {

    var tx = jQuery('#commttxa').val();
    var mail = jQuery('#comentmailpst').val();
    var mob = jQuery('#comentmobpst').val();
    var fuln = jQuery('#comentfullnpst').val();
    var erstr = "";

    if (tx.length < 3) {
        erstr += "پیام وارد نشده" + "<br>";
    }
    if (fuln.length < 3) {
        erstr += "نام وارد شده معتبر نیست"+"<br>";
    }
    //if (validateEmail(mail) == false) {
     //   erstr += "ایمیل وارد شده معتبر نیست"+"<br>";
    //}
    if ((mob.length<7)) {
        erstr += "موبایل وارد شده معتبر نیست" + "<br>";
    }
    if (isNullOrWhitespace(erstr) == true) {
        saveoff('myfullname', fuln);
        saveoff('mymobile', mob);
        saveoff('myemail', mail);
        showWait(31);
        socket.emit('MGsendcomment', { dfuln: fuln, dmob: mob, dmail: mail, dtx: tx, dpst: dlatestpstid });
    } else {
        app.dialog.alert(erstr, 'خطای ثبت');
    }
}

function getwritername(id) {
    for (var r = 0; r <= MGritersdb.length - 1; r++) {
        if (MGritersdb[r].id == id) {
            return MGritersdb[r];
        }
    }
}

var latestdvid4shansi = "";
var latestname4dt = "";
function getshamsi(dvid, dt) {
    latestdvid4shansi = dvid;
    socket.emit('getshamsi', { ddt: dt });
}
function getshamsiseri(dvid, dt) {
    latestdvid4shansi = dvid;
    socket.emit('getshamsiseri', { ddt: dt });
}
function getrelateimages(ids){
console.log('go get: '+ids);
showWait(33);
socket.emit('getrelateimages', { dids: ids });
}
function getsardabirpost(){
	showWait(34);
socket.emit('getpostbytit', { dtit: 'پیشنهاد سر دبیر' });
}