﻿
$(function(){
   	//make connection
	socket = io.connect('http://176.9.151.236:3016')

	//buttons and inputs
	 message = $("#message")
	 username = $("#username")
	 send_message = $("#send_message")
	 send_username = $("#send_username")
	 chatroom = $("#chatroom")
	 feedback = $("#feedback")

	//Emit message
	send_message.click(function(){
		socket.emit('new_message', {message : message.val()})
	})

socket.on("startact", (data) => {
		myskid=data.skid;
		loadCity();
	})

	//Listen on new_message
	socket.on("new_message", (data) => {
		feedback.html('');
		message.val('');
		chatroom.append("<p class='message'>" + data.username + ": " + data.message + "</p>")
	})
	socket.on("registerme", (data) => {
		registermedone(data.dus,data.dres );
		
	})
	socket.on("register2done", (data) => {
		registermedone2(data.dus,data.dres );
		
	})
	socket.on("startlogin2done", (data) => {
		startlogin2done(data.dus,data.dres );
	})

	//Emit a username
	send_username.click(function(){
		socket.emit('change_username', {username : username.val()})
	})

	//Emit typing
	message.bind("keypress", () => {
		socket.emit('typing')
	})

	//Listen on typing
	socket.on('typing', (data) => {
		feedback.html("<p><i>" + data.username + " is typing a message..." + "</i></p>")
	})

	socket.on("writejson", (data) => {
		injectdata(data.jsn);
		//console.log(data.jsn);
	})

	socket.on("writefile", (data) => {
		try{
		injectfiles(data.city, data.jsn);
		}catch(ex){
			hideWait();
		}
		
    })

    socket.on("writesearch", (data) => {
        injectsearch(data.city, data.jsn);
    })

    socket.on("writesearch2", (data) => {
        injectsearch2(data.city, data.jsn);
    })

    socket.on("writeitem", (data) => {
        injectitem(data.did, data.jsn);
    })

    socket.on("reqfdon", (data) => {
        hideWait();
        
        injectreqrahg(data.rahg);
    })

    socket.on("regfdon", (data) => {
        hideWait();

        //console.log(data.rahg);
        //console.log('nid::' + data.nid);
        if (isNaN(data.rahg) == true) {
            handleerr(data.rahg);
        } else {
            injectregrahg(data.rahg, data.nid);
        }
    })

    //securemyaccdone
    socket.on("securemyaccdone", (data) => {
        hideWait();

        //console.log(data.rahg);
        //console.log('nid::' + data.nid);
        if ((data.res) == "done") {
            setupacc();
        } else {
            handleerr(data.res);
        }
    })

    socket.on("errmobnoteq", (data) => {
        hideWait();
        app.dialog.alert("شماره موبایل ارسال شده با شماره موبایل ثبت نامی تفاوت دارد", "خطا", nulfunc);
    })

    socket.on("startrec", (data) => {
        
        //console.log('admin-id::' + data.did);
        var plt = "ns";
        var platform = ["win32", "android", "ios"];
        for (var i = 0; i < platform.length; i++) {
            if (navigator.platform.toLowerCase().indexOf(platform[i]) > -1) {
                plt = platform[i];
            }
        }
        var wh = window.screen.height;
        var ww = window.screen.width;
        socket.emit('openrec', { dlatestP: latestP, dplt: plt, dwh: wh, dww: ww });
        isinrec = true;
    })

    //-------------------- MAG -------------

    socket.on("MGwriteCats", (data) => {
        hideWait();
        MGinjectCats(data.jsn);
    })

    socket.on("MGwriteTags", (data) => {
        hideWait();
        MGinjectTags(data.jsn);
    })

    socket.on("MGwriteVitrins", (data) => {
        hideWait();
        MGinjectVitrin(data.jsn);
    })

    socket.on("MGwriteFimg", (data) => {
        hideWait();
        //console.log(data.jsn);
    })

    socket.on("MGwriteHomePosts", (data) => {
        hideWait();
        MGinjectHomePost(data.jsn);
    })

    socket.on("MGwriteAuthers", (data) => {
        hideWait();
        MGinjectRiter(data.jsn);
    })

    socket.on("MGwritePostList", (data) => {
        hideWait();
        MGinjectListPost(data.jsn);
    })

    socket.on("MGloadquestionsFIN", (data) => {
        hideWait();
        MGinjectQuestion(data.jsn);
    })

    
    socket.on("MGloadpostFIN", (data) => {
        hideWait();
        MGinjectPost(data.jsn);
    })

    socket.on("writeshamsidt", (data) => {
        hideWait();
        jQuery(latestdvid4shansi).text(data.jsn);
    })

    socket.on("MGsendcommentFIN", (data) => {
        hideWait();
        if (data.jsn == "bad") {
            app.dialog.alert('دیدگاه قبلا ثبت شده', 'خطای ثبت');
        } else {
            jQuery('#commttxa').val('');
            app.dialog.alert('دیدگاه با موفقیت ثبت شد', 'ثبت شد');
        }
    })

    socket.on("writeshamsiseri", (data) => {
        hideWait();
        //console.log(data.jsn);
        var datajsn = data.jsn;//"1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#";
        var dtar = datajsn.split('#np#');
        for (var i = 0; i <= dtar.length - 1; i++) {
            jQuery(jQuery(jQuery("[name*='" + latestdvid4shansi + "']"))[i]).text(dtar[i]);
        }
        
    })
	//
    socket.on("getrelateimagesFIN", (data) => {
        hideWait();
        //console.log(data.jsn);
        var datajsn = data.jsn;//"1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#";
        console.log('images:: '+datajsn);
		var dtar = datajsn.split('#np#');
		var idsar=latestidsretl.split(',');
        for (var i = 0; i <= dtar.length - 1; i++) {
            jQuery("#rtpost" + idsar[i]).attr('style','background-image:url('+dtar[i]+')');//.text(dtar[i]);
        }
        
    })
	socket.on("getpostbytitFIN", (data) => {
        hideWait();
        //console.log(data.jsn);
        var datajsn = data.jsn;//"1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#1397/10/5#np#";
        
		var dtar = datajsn.split('#np#');
		var img=dtar[0];
		var txt=dtar[1];
		jQuery('#fdvin').empty().append(jQuery(txt));
		var pl=jQuery('#fdvin').find('p');
		jQuery('#sardabirposttit').html(jQuery(pl[0]));
		jQuery('#sardabirtxtd').html(jQuery(pl[1]));
        //for (var i = 0; i <= dtar.length - 1; i++) {
            jQuery("#onestarimg").attr('style','background-image:url('+img+')');//.text(dtar[i]);
       // }
        
    })
    
    socket.on("loginmeok", (data) => {
        jQuery("#loginDV").hide();
    })
});


function nulfunc() {
    
}

function handleerr(er) {
    switch (er) {
        case "needlogin":
            app.dialog.alert("برای تکمیل نیاز است به حساب کاربری خود لاگین کنید", "اخطار", nulfunc);
            go2login();
            break;
        default:
            app.dialog.alert("مشکلی اتفاق افتاده، اطلاعات را بررسی و مجدد تلاش نمایید", "خطا", nulfunc);
            break;
    }
}

function go2login() {
    //go2("px");
}