<?php
class stdObject {
    public function __construct(array $arguments = array()) {
        if (!empty($arguments)) {
            foreach ($arguments as $property => $argument) {
                $this->{$property} = $argument;
            }
        }
    }

    public function __call($method, $arguments) {
        $arguments = array_merge(array("stdObject" => $this), $arguments); // Note: method argument 0 will always referred to the main class ($this).
        if (isset($this->{$method}) && is_callable($this->{$method})) {
            return call_user_func_array($this->{$method}, $arguments);
        } else {
            throw new Exception("Fatal error: Call to undefined method stdObject::{$method}()");
        }
    }
}

class dpost
{
public $id;
public $part;
public $tit;
public $img1;
public $stx;
public $dat;
public $riter;
}
class dads
{
public $id;
public $part;
public $tit;
public $img1;
public $link;
public $expir;
}
class dconf
{
public $id;
public $part;
public $tit;
public $val;
}

?>
<?php 

//die('fertig');

//ini_set('memory_limit','34M');
//require_once dirname(__FILE__) . '/jdatetime.class.php';
//$date = new jDateTime(true, true, 'Asia/Tehran');
//"2018-11-30 14:00:47"

error_reporting(E_ALL);
ini_set('display_errors', 1);

require($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);


global $wpdb;
$wpdb->show_errors = true;


$dblog = 70;


//$cmd=$_REQUEST['cmd'];
$cmd=$_REQUEST['cmd'];
$api=$_REQUEST['api'];
//echo $cmd;


//------------------------------------functions---------------------
function url_get_image_id($image_url) {
global $wpdb;
$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url ));
return $attachment[0];
}

//------------------------------------------------------------------

$rtv = "";
$dnow = (new \DateTime())->format('Y-m-d H:i:s');

switch ($api) {

//api:"dwp",cmd:"MGgetCats"

	case "dwp":
		switch_to_blog( $dblog );
		switch ($cmd) {



			case "MGdookcomment":
				$did=(int)$_REQUEST['cid'];
				wp_set_comment_status( $did, 1 );
				$rtv='ok';

			break;
			case "MGsendcomment":
				$did=(int)$_REQUEST['pst'];
				$time = current_time('mysql');

				//: data.dfuln, : data.dmob, mail: data.dmail, tx: data.dtx

				//$did=$_REQUEST['pst'];
				$fuln=$_REQUEST['fuln'];
				$mob=$_REQUEST['mob'];
				$mail=$_REQUEST['mail'];
				$tx=$_REQUEST['tx'];

				$data = array(
				'comment_post_ID' => $did,
				'comment_author' => $fuln,
				'comment_author_email' => $mail,
				'comment_author_url' => $$mob,
				'comment_content' => $tx,
				'comment_type' => '',
				'comment_parent' => 0,
				'user_id' => 0,
				'comment_author_IP' => '127.0.0.1',
				'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
				'comment_date' => $time,
				'comment_approved' => 0,
				);

				wp_insert_comment($data);

				$rtv='ok';

			break;
			case 'getrelateimages':
				$ids=$_REQUEST['ids'];
				$teile = explode(",", $ids);
				for ($i=0; $i < sizeof($teile)-1; $i++) { 
					if($teile[$i] != ""){
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( (int)$teile[$i] ), 'single-post-thumbnail' )[0];
	$rtv = $rtv . $image . "#np#";	
}
				}

				break;
				case 'getpostbytit':
				$tit=$_REQUEST['tit'];
					$args = array("post_type" => "post", "s" => $tit);
					$query = get_posts( $args )[0];
$image = wp_get_attachment_image_src( get_post_thumbnail_id( $query->ID ), 'single-post-thumbnail' )[0];
	$rtv = $image . "#np#" . $query->post_content ;	

					break;
			case "MGloadpost":
				$did=(int)$_REQUEST['id'];
				$post = get_post( $did );
				

				$reta=array();

				$max = sizeof($reta);
				array_push($reta,$max,($post));

				$post_categories = wp_get_post_categories( $did );

				$max = sizeof($reta);
				array_push($reta,$max,$post_categories);



$args = array(

'post_ID' => $did, // ignored (use post_id instead)

);
$comnts = get_comments( $args ); 

$max = sizeof($reta);
				array_push($reta,$max,$comnts);


$t = wp_get_post_tags($did);
$max = sizeof($reta);
array_push($reta,$max,$t);



$related = get_posts( array( 'category__in' => wp_get_post_categories($did), 'numberposts' => 5, 'post__not_in' => array($did) ) );
$max = sizeof($reta);
array_push($reta,$max,$related);

//insert into wp_dlt_likes (sid,likcont,dus,dpost,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,1,#sq#nam#sq#,12,0,0,1,0,0)
//$query = "select sum(likcont) from wp_dlt_likes where dpost = '" . $did . "'";
$query="SELECT FORMAT(SUM(likcont),2) total FROM wp_dlt_likes WHERE dpost = '" . $did . "';";
				$results = $wpdb->get_results( $query, OBJECT );

$max = sizeof($reta);
array_push($reta,$max,$results);

				$rtv = json_encode($reta);

			break;
			case "MGgetListTag":
				$tit=$_REQUEST['tit'];
				/*$cid = get_cat_ID( $tit );
				$args = array(
				'posts_per_page' => 100,
				'cat' => ((int)$cid), 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);*/


$args = array(
'posts_per_page' => '100',
'tax_query' => array(
array(
'taxonomy' => 'post_tag',
'field' => 'slug', //Can use 'name' if you need to pass the name to 'terms
'terms' => $tit, //Use the slug of the tag
),
),
);
//$query = new WP_Query( $args );



				$reta=array();
				$posts = get_posts($args);
				foreach( $posts as $recent ){
					
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_1";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}

					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$ddt="2018-11-30 14:00:47";//$recent->post_date
					//$ndd = $date->date("y-m-d h:m:s", $ddt, false, true, 'Asia/Tehran'); 
					//$nc->dat=$ndd;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}
				$rtv = json_encode($reta);
			break;

			case "MGgetListTag0":
				$tit=$_REQUEST['tit'];
				//$cid = get_cat_ID( $tit );

$reta=array();
$the_query = new WP_Query( 'tag='.$tit );

if ( $the_query->have_posts() ) {

while ( $the_query->have_posts() ) {
	$recent->the_post();
	$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_1";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}

					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$ddt="2018-11-30 14:00:47";//$recent->post_date
					//$ndd = $date->date("y-m-d h:m:s", $ddt, false, true, 'Asia/Tehran'); 
					//$nc->dat=$ndd;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
}

} else {
// no posts found
}
/* Restore original Post Data */
wp_reset_postdata();

			/*	$args = array(
				'posts_per_page' => 100,
				"tax_query" => array(
					array(
					"taxonomy" => "tag",
					"field" => "name",
					"terms" => $tit,
					)
					), 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$reta=array();
				$posts = get_posts($args);
*/

//$query = new WP_Query( array( 'tag' => $tit ) );

				//foreach( $posts as $recent ){
					
					
				//}
				$rtv = json_encode($reta);

			break;
			case "MGgetListCat":
				$tit=$_REQUEST['tit'];
				$cid = get_cat_ID( $tit );
				$args = array(
				'posts_per_page' => 100,
				'cat' => ((int)$cid), 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$reta=array();
				$posts = get_posts($args);
				foreach( $posts as $recent ){
					
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_1";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}

					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$ddt="2018-11-30 14:00:47";//$recent->post_date
					//$ndd = $date->date("y-m-d h:m:s", $ddt, false, true, 'Asia/Tehran'); 
					//$nc->dat=$ndd;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}
				$rtv = json_encode($reta);
			break;

			case "MGgetRiters":
				$users = get_users();
				foreach ($users as $user)
				{
					$rtv = $rtv . $user->ID . "," . $user->display_name . "nnpp";
				}
			break;
			case "MGgetHomePosts":
				//------- vitrin
				$reta=array();
				
				//$args0 = array( 'numberposts' => '9' );
				$args = array(
				'posts_per_page' => 9,
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$recent_posts = get_posts( $args );

				//$recent_posts = wp_get_recent_posts($args);
				foreach( $recent_posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="vit";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];//.split(pattern, string);
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}


				$query = "select * from wp_dlt_ads where actif != 'false' order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				foreach( $results as $rec ){
					$nc = new dads();
					
					$nc->id=$rec->id;
					$nc->part="ads";
					$nc->tit=$rec->tit;
					$nc->img1=$rec->dimg;
					$nc->link=$rec->dlink;
					$nc->expir=$rec->expir;
					
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$opt_subcat_1 = "";
				$opt_subcat_2 = "";
				$opt_subcat_3 = "";
				$opt_subcat_4 = "";
				$opt_subcat_5 = "";
				$opt_subcat_6 = "";
				$opt_subcat_7 = "";
				$opt_subcat_8 = "";
				
				$query = "select * from wp_ConfigsTbl where sid=62 order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				foreach( $results as $rec ){
					$nc = new dconf();
					
					$nc->id=$rec->id;
					$nc->part="conf";
					$nc->tit=$rec->dieName;
					$nc->val=$rec->dieXml;
					
					switch ($rec->dieName) {
							case 'opt_subcat_1':
								$opt_subcat_1=$rec->dieXml;
								break;
							case 'opt_subcat_2':
								$opt_subcat_2=$rec->dieXml;
								break;
							case 'opt_subcat_3':
								$opt_subcat_3=$rec->dieXml;
								break;
							case 'opt_subcat_4':
								$opt_subcat_4=$rec->dieXml;
								break;
							case 'opt_subcat_5':
								$opt_subcat_5=$rec->dieXml;
								break;
							case 'opt_subcat_6':
								$opt_subcat_6=$rec->dieXml;
								break;
							case 'opt_subcat_7':
								$opt_subcat_7=$rec->dieXml;
								break;
							case 'opt_subcat_8':
								$opt_subcat_8=$rec->dieXml;
								break;
							
							default:
								# code...
								break;
						}	

					
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$opt_subcat_1 = get_cat_ID( $opt_subcat_1 );// str_replace(" ","-",$opt_subcat_1);
				$opt_subcat_2 = get_cat_ID( $opt_subcat_2 );//str_replace(" ","-",$opt_subcat_2);
				$opt_subcat_3 = get_cat_ID( $opt_subcat_3 );//str_replace(" ","-",$opt_subcat_3);
				$opt_subcat_4 = get_cat_ID( $opt_subcat_4 );//str_replace(" ","-",$opt_subcat_4);
				$opt_subcat_5 = get_cat_ID( $opt_subcat_5 );//str_replace(" ","-",$opt_subcat_5);
				$opt_subcat_6 = get_cat_ID( $opt_subcat_6 );//str_replace(" ","-",$opt_subcat_6);
				$opt_subcat_7 = get_cat_ID( $opt_subcat_7 );//str_replace(" ","-",$opt_subcat_7);
				$opt_subcat_8 = get_cat_ID( $opt_subcat_8 );//str_replace(" ","-",$opt_subcat_8);

				/*$args = array(
				'posts_per_page' => 6, 
				'category_name' => $opt_subcat_1, 
				'orderby' => 'date', 'order' => 'DESC' 
				);*/

				$args = array(
				'posts_per_page' => 6,
				'cat' => ((int)$opt_subcat_1), 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);


				$posts = get_posts($args);
				foreach( $posts as $recent ){
					
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_1";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}

					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$ddt="2018-11-30 14:00:47";//$recent->post_date
					//$ndd = $date->date("y-m-d h:m:s", $ddt, false, true, 'Asia/Tehran'); 
					//$nc->dat=$ndd;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				
	$args = array(
				'posts_per_page' => 6,
				'cat' => $opt_subcat_2, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_2";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$args = array(
				'posts_per_page' => 6,
				'cat' => $opt_subcat_3, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_3";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$args = array(
				'posts_per_page' => 6,
				'cat' => $opt_subcat_4, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_4";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$args = array(
				'posts_per_page' => 6,
				'cat' => $opt_subcat_5, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_5";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$args = array(
				'posts_per_page' => 8,
				'cat' => $opt_subcat_6, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_6";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$args = array(
				'posts_per_page' => 4,
				'cat' => $opt_subcat_7, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_7";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$linetxt = htmlspecialchars(trim(strip_tags($recent->post_content)));
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}

				$args = array(
				'posts_per_page' => 4,
				'cat' => $opt_subcat_8, 
				'orderby' => 'date',
				'order' => 'DESC',
				'post_status' => 'publish',
				);

				$posts = get_posts($args);
				foreach( $posts as $recent ){
					$nc = new dpost();
					$nc->id=$recent->ID;
					$nc->part="opt_subcat_8";
					$nc->tit=$recent->post_title;
					if (has_post_thumbnail( $recent->ID ) ){ 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $recent->ID ), 'single-post-thumbnail' )[0];
	$nc->img1=$image;					
}else{
					$nc->img1=the_post_thumbnail('thumbnail');
				}
					$content_arr = get_extended ( $recent->post_content );
					$nc->stx=$content_arr['main'];
					//$nc->dat=$recent->post_date;
					$nc->dat="#nd#" . $recent->post_date . "#nd#";
					$nc->riter=$recent->post_author;
					$max = sizeof($reta);
					array_push($reta,$max,$nc);
				}


				$rtv = json_encode($reta);//$reta);
			break;
			case "MGsetfimg":
				switch_to_blog( $dblog );
				$lastposts = get_posts(array(
				'posts_per_page' => 3000
				) );
				foreach( $lastposts as $post ){

					global $post;
					$content = $post->post_content;
					$first_img = '';
					ob_start();
					ob_end_clean();
					$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $content, $matches);
					$first_img = $matches[1][0];
					$image_id = url_get_image_id($first_img);
					
					if(empty($first_img) == false){
						set_post_thumbnail($post->ID, $image_id);
						$rtv = $rtv . $image_id . " , ";
					}
					/*
					if (!has_post_thumbnail($post->ID)) {
						
						ob_start();
						ob_end_clean();
						$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
						try{
						$first_img = $matches [1] [0];

						if(empty($first_img)){ //Defines a default image
						$first_img = "/images/default.jpg";
						}

						$rtv = $rtv . $first_img . " , ";
						} catch (Exception $e) {
						    $rtv = $rtv . "ERR" . " , ";
						}

						//set_post_thumbnail($post->ID, $attachment_id);

					}
*/
				}
				//$rtv="OK200";
			break;

			case 'MGgetVitrin':
				$args = array( 'numberposts' => '9' );

				$recent_posts = wp_get_recent_posts($args);
				foreach( $recent_posts as $recent ){
echo '<li><a href="' . get_permalink($recent["ID"]) . '">' . $recent["post_title"].'</a> </li> ';
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
the_post_thumbnail('thumbnail');
}
}
			break;
			case 'MGgetCats':
				switch_to_blog( $dblog );
				$categories = get_categories( array(
				'orderby' => 'name',
				'order' => 'ASC'
				) );

				foreach( $categories as $category ) {
					$rtv = $rtv . $category->term_id . "," . $category->name . "," . $category->parent . "nnpp"  ;
				}
				break;
			case 'MGgetTags':
				switch_to_blog( $dblog );
				$tags = get_tags( array(
				'orderby' => 'count',
				'order' => 'DESC'
				) );

				foreach( $tags as $tag ) {
					$rtv = $rtv . $tag->term_id . "," . $tag->name . "," . $tag->count . "nnpp"  ;
				}
				break;	
		}

	break;	
	case "sql":

		switch ($cmd) {
			//insert query : insert into wp_adm_sqdev (sid,sqtit,sqtx,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#registerme#sq#,#sq##sq#,0,0,1,0,0)

			//query = "insert into wp_dlt_files (sid,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,0,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#"+DateTime.Now.ToString()+"#sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,0,#sq#"+dres+"#sq#,#sq#"+lastfileurl+"#sq#,0,0,1,0,0)";


			//var propertiesObject = { api:"sql",cmd:"sendRegF", searchTyp: data.dsearchTyp, dfullname: data.fullname, dmobile: data.mobile, dmail: data.mail, mahallst: data.mahal, dmainalay: data.mainalay, dcapacity: data.capacity, dbanacapacity: data.banacapacity, dtoolebar: data.toolebar, dfloor: data.floor, dfloorcont: data.floorcont, drooms: data.rooms, dage: data.age, dfullprice: data.fullprice, drentprice: data.rentprice, descparams: data.ddescparams, desctxt: data.ddesctxt, dimg1: data.img1, dimgs2: data.imgs2 };


			//cmd:"MGADMsavedquestions", qwsname: data.dqwsname, qwsanswer:data.dqwsanswer
			
			case "MGADMsavedquestions":

				$qwsname=$_REQUEST['qwsname'];
				$qwsanswer=$_REQUEST['qwsanswer'];
				$qwsid=$_REQUEST['qwsid'];

				if($qwsid == "0"){

					$query="insert into wp_dlt_qsanswer (sid,dperson2,dperson1,dans,ddate,dqtit,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#admin#sq#,#sq#user#sq#,#sq#" . $qwsanswer . "#sq#,#sq#" . $dnow . "#sq#,#sq#" . $qwsname . "#sq#,0,0,1,0,0)";

					$query=str_replace("#sq#","'",$query);
					$results = $wpdb->query(
							        	$query
									);
				}else{

					$query="update wp_dlt_qsanswer set dans='" . $qwsanswer . "',ddate='" . $dnow . "',dqtit='" . $qwsname . "' where id=" . $qwsid;

					$query=str_replace("#sq#","'",$query);
					$results = $wpdb->query(
							        	$query
									);

				}	

				$query = "select * from wp_dlt_qsanswer order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				$rtv = json_encode($results);

			break;

			case "MGloadquestions":
				$query = "select * from wp_dlt_qsanswer order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				$rtv = json_encode($results);

			break;
			case "MGLoadAds":
				$query = "select * from wp_dlt_ads where actif='true' order by id desc";
				//$query = "select dcheck from wp_dlt_requests where (dcheck = 'false') order by id desc";

				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);
			break;
			
			case "MGADMsavedconstans":
				$lbl_sabkzendegi=$_REQUEST['lbl_sabkzendegi'];
				$query="update wp_ConfigsTbl set dieXml='" . $lbl_sabkzendegi . "' where dieName='lbl_sabkzendegi'";
				$results = $wpdb->query(   	$query	);

				$lbl_jadidtandorosti=$_REQUEST['lbl_jadidtandorosti'];
				$query="update wp_ConfigsTbl set dieXml='" . $lbl_jadidtandorosti . "' where dieName='lbl_jadidtandorosti'";
				$results = $wpdb->query(   	$query	);

				$lbl_videobartar=$_REQUEST['lbl_videobartar'];
				$query="update wp_ConfigsTbl set dieXml='" . $lbl_videobartar . "' where dieName='lbl_videobartar'";
				$results = $wpdb->query(   	$query	);

				$lbl_modjadid=$_REQUEST['lbl_modjadid'];
				$query="update wp_ConfigsTbl set dieXml='" . $lbl_modjadid . "' where dieName='lbl_modjadid'";
				$results = $wpdb->query(   	$query	);

				$lbl_deltaapp=$_REQUEST['lbl_deltaapp'];
				$query="update wp_ConfigsTbl set dieXml='" . $lbl_deltaapp . "' where dieName='lbl_deltaapp'";
				$results = $wpdb->query(   	$query	);

				$lbl_deltamag=$_REQUEST['lbl_deltamag'];
				$query="update wp_ConfigsTbl set dieXml='" . $lbl_deltamag . "' where dieName='lbl_deltamag'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_1=$_REQUEST['opt_subcat_1'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_1 . "' where dieName='opt_subcat_1'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_2=$_REQUEST['opt_subcat_2'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_2 . "' where dieName='opt_subcat_2'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_3=$_REQUEST['opt_subcat_3'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_3 . "' where dieName='opt_subcat_3'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_4=$_REQUEST['opt_subcat_4'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_4 . "' where dieName='opt_subcat_4'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_5=$_REQUEST['opt_subcat_5'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_5 . "' where dieName='opt_subcat_5'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_6=$_REQUEST['opt_subcat_6'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_6 . "' where dieName='opt_subcat_6'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_7=$_REQUEST['opt_subcat_7'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_7 . "' where dieName='opt_subcat_7'";
				$results = $wpdb->query(   	$query	);

				$opt_subcat_8=$_REQUEST['opt_subcat_8'];
				$query="update wp_ConfigsTbl set dieXml='" . $opt_subcat_8 . "' where dieName='opt_subcat_8'";
				$results = $wpdb->query(   	$query	);

				//insert into wp_ConfigsTbl (sid,dieName,dieVal,dieXml,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#config1#sq#,123,#sq#txt#sq#,0,0,1,0,0)

				$rtv="ok";

			break;

			case "MGADMsavedieads":
				//skid: data.dmyskid, :data.dactifads, :data.dimg, :data.dtit, :data.dlink, :data.dexpir, :data.dactif, :data.dpart, :data.dcadr
				$dactifads=$_REQUEST['actifads'];
				$dimg=$_REQUEST['img'];
				$dtit=$_REQUEST['tit'];
				$dlink=$_REQUEST['link'];
				$dexpir=$_REQUEST['expir'];
				$dactif=$_REQUEST['actif'];
				$dpart=$_REQUEST['part'];
				$dcadr=$_REQUEST['cadr'];

				$Today=date('y:m:d');

// add 3 days to date
$expir2=$dexpir;//Date('y:m:d', strtotime("+" . $dexpir ." days"));

				//$data0 = explode('nnpp', $imgs2)[0];//'data:image/png;base64,AAAFBfj42Pj4';
//die($dimg);
//if()
			$img1="";
			if($dimg != ""){
				$imgdata = base64_decode($dimg);

				$f = finfo_open();

				$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);


				$ext = ".png";
				$has_jpg = (strpos($mime_type, '/jpg') !== false) || (strpos($mime_type, '/jpeg') !== false);
				if($has_jpg === true){
					$ext = '.jpg';
				}

				//$data = base64_decode($data0);

				list($usec, $sec) = explode(" ", microtime());
				$ticks = (int)($sec*10000000+$usec*10000000);

				file_put_contents('/var/www/maxim.shop/hototo/files/' . $ticks . $ext, $imgdata);
				
				$nowdt=date('m/d/Y h:i:s');

				$img1='http://heram.shop/hototo/files/' . $ticks . $ext;
			}else{
				$query="select * from wp_dlt_ads where id=" . $dactifads . "";
				$results = $wpdb->get_results( $query, OBJECT );
				foreach($results as $fv) {
				    $img1=($fv->dimg);
				    
				    break;
				}

			}
				

				$query="insert into wp_dlt_ads (sid,tit,dimg,dlink,clik,actif,expir,part,dcadr,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#" . $dtit . "#sq#,#sq#" . $img1 . "#sq#,#sq#" . $dlink . "#sq#,0,#sq#" . $dactif . "#sq#,#sq#" . $expir2 . "#sq#,#sq#" . $dpart . "#sq#," . $dcadr . ",0,0,1,0,0)";	


				if($dactifads != "0"){
					$query="update wp_dlt_ads set tit='" . $dtit . "', dlink='" . $dlink . "', actif='" . $dactif . "', expir='" . $expir2 . "' where id=" . $dactifads;
				}

				$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
				//die($query);
				$query = "select * from wp_dlt_ads order by id desc";
				//$query = "select dcheck from wp_dlt_requests where (dcheck = 'false') order by id desc";

				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);


			break;

			case "xx":
				//insert into wp_dlt_user (sid,dregdate,dfullname,dmail,dpass,dmob,dusn,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#date#sq#,#sq#fullname#sq#,#sq#email#sq#,#sq#pass#sq#,#sq#mob#sq#,#sq#usn#sq#,0,0,1,0,0)

			break;
			case "changereqstat":
				$did=$_REQUEST['did'];
				$fstat=$_REQUEST['fstat'];
				$query="update wp_dlt_requests set dcheck = 'true' where id=" . $did;
				//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
				$rtv=$query;
			break;
			case "adm-loadreqstlist2":
				$query = "select * from wp_dlt_requests where (dcheck = 'false') order by id desc";
				//$query = "select dcheck from wp_dlt_requests where (dcheck = 'false') order by id desc";

				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);
			break;
			case "changeFileStat":
			 	$fid=$_REQUEST['fid'];
				$fstat=$_REQUEST['fstat'];
				$query="update wp_dlt_files set actif='" . $fstat . "' where id=" . $fid;
				//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
				$rtv=$query;

			break;

			case "dosavefile":
				$fid=$_REQUEST['fid'];
				$ftit=$_REQUEST['ftit'];
				$ftx=$_REQUEST['ftx'];
				$query="update wp_dlt_files set dtitr='" . $ftit . "',desctxt='" . $ftx . "' where id=" . $fid;
				//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
				$rtv=$query;

			break;


			case "adm-saveregads":

				$dtitr=$_REQUEST['ntit'];
				$dactifrec=$_REQUEST['actifrec'];
				$query="update wp_dlt_files set dtitr='" . $dtitr . "' where id=" . $dactifrec;
				//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
				$rtv=$query;

			break;
			case "adm-loadreglist2":
				//$query = "select * from wp_dlt_files where (dcod like '%ns%') order by id desc";
				$query = "select id, dexpir,dtyp, dtitr , descparams,drentprice,dfullprice, mahal, SUBSTRING(desctxt, 0, 85) AS desctxt2, dage, dfloor, drooms, TIMESTAMPDIFF(SECOND,STR_TO_DATE(dexpir, '%m/%d/%Y %h:%i:%s'),NOW()) AS dexpir2, ajans, ROUND ( ( LENGTH(dimgs2) - LENGTH( REPLACE ( dimgs2, 'nnpp', '') ) ) / LENGTH('nnpp') ) AS img2num, dimg1 from wp_dlt_files where (actif = 'regnotcheck') order by id desc";

				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);
//$rtv=$query;
			break;
			case 'adm-loadreqstlist':
				$query = "select * from wp_dlt_requests where (dcheck='false') order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);

			break;

			case "securemyacc":
				//, mypass:data.dmypass , mymobile:data.dmymobile
				//$query = "insert into wp_dlt_user (sid,issecure,dregdate,dfullname,dmail,dpass,dmob,dusn,ownerTbl,ownerRec,isSingle,isExist,isNew) 
				$mymobile = $_REQUEST['mymobile'];
				$mypass = $_REQUEST['mypass'];
				$query = "select count(id) from wp_dlt_user where (dmob='" . $mymobile . "') and (issecure='false') order by id desc";
				$rescont =(int) $wpdb->get_results( $query, OBJECT );
				$rtv = 'err';
				if($rescont == 1){
					$query = "update wp_dlt_user set issecure='true', dpass='" . $mypass . "' where (dmob='" . $mymobile . "')";
					$rtv = 'done';
				}
				$results = $wpdb->query(
						        	$query
								);


			break;

			case "sendRegF4us":
				$rahg = "";//microtime(true) * 10000000;
				$rgy = $_REQUEST['drgy'];
				$rgm = $_REQUEST['drgm'];
				$rgd = $_REQUEST['drgd'];
				$rtv = strval($rgy) . strval($rgm) . strval($rgd);// . $lid;


				$searchTyp=$_REQUEST['searchTyp'];
				$actifCity=$_REQUEST['actifCity'];
				$actifState=$_REQUEST['actifState'];
				$fullname=$_REQUEST['dfullname'];
				$mobile=$_REQUEST['dmobile'];
				$mail=$_REQUEST['dmail'];
				$mahallst=$_REQUEST['mahallst'];
				$mainalay=$_REQUEST['dmainalay'];
				$capacity=$_REQUEST['dcapacity'];
				$banacapacity=$_REQUEST['dbanacapacity'];
				$toolebar=$_REQUEST['dtoolebar'];
				$floor=$_REQUEST['dfloor'];
				$floorcont=$_REQUEST['dfloorcont'];
				$rooms=$_REQUEST['drooms'];
				$age=$_REQUEST['dage'];
				$fullprice=$_REQUEST['dfullprice'];
				$rentprice=$_REQUEST['drentprice'];
				$descparams=$_REQUEST['descparams'];
				$desctxt=$_REQUEST['desctxt'];
				$img1=$_REQUEST['dimg1'];
				$imgs2=$_REQUEST['dimgs2'];
				$ddactifUsage=$_REQUEST['ddactifUsage'];
				$darzegozar=$_REQUEST['darzegozar'];
				$darzeshemelk=$_REQUEST['darzeshemelk'];
				$dsarghofliprice=$_REQUEST['dsarghofliprice'];
				$dtit=$_REQUEST['dtit'];
				$dmap=$_REQUEST['map'];


$query = "select count(mobile) from wp_dlt_user where (mobile = '" . $mobile . "') order by id desc";
				$rescont =(int) $wpdb->get_results( $query, OBJECT );


if($rescont == 0){

$dnid=$_REQUEST['nid'];
if( $dnid != "0" ){
	$query="delete from wp_dlt_files where id=" . $dnid;
	$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
}


list($usec, $sec) = explode(" ", microtime());
$ticks = (int)($sec*10000000+$usec*10000000);


				$data0 = explode('nnpp', $imgs2)[0];//'data:image/png;base64,AAAFBfj42Pj4';

$imgdata = base64_decode($data0);

$f = finfo_open();

$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
//$rtv = mime_type

				$ext = ".png";
$has_jpg = (strpos($mime_type, '/jpg') !== false) || (strpos($mime_type, '/jpeg') !== false);
if($has_jpg === true){
	$ext = '.jpg';
}

//list($type, $data) = explode(';', $data);
//list(, $data) = explode(',', $data);
$data = base64_decode($data0);

file_put_contents('/var/www/maxim.shop/hototo/files/' . $ticks . $ext, $data);
				
				$nowdt=date('m/d/Y h:i:s');

				$img1='http://heram.shop/hototo/files/' . $ticks . $ext;
				//$imgs2='';

				$query = "insert into wp_dlt_files (sid,dtitr,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,dmap,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#" . $dtit . "#sq#,#sq##sq#,0,#sq#" . $darzeshemelk . "#sq#,#sq#" . $darzegozar . "#sq#,#sq#" . $dsarghofliprice . "#sq#,#sq#false#sq#,#sq#" . $banacapacity . "#sq#,#sq#" . $toolebar . "#sq#,#sq#" . $desctxt . "#sq#,#sq#" . $descparams . "#sq#,#sq#" . $rentprice . "#sq#,#sq#" . $fullprice . "#sq#,#sq#" . $age . "#sq#,#sq#" . $rooms . "#sq#,#sq#" . $floorcont . "#sq#,#sq#" . $floor . "#sq#,#sq#" . $capacity . "#sq#,#sq#" . $mainalay . "#sq#,#sq#" . $actifState . "#sq#," . $actifCity . ",#sq#" . $mail . "#sq#,#sq#" . $mobile . "#sq#,#sq#" . $fullname . "#sq#,#sq#" . $nowdt . "#sq#,#sq#regnotcheck#sq#,#sq#" . $ddactifUsage . "#sq#,#sq#" . $imgs2 . "#sq#,#sq#" . $img1 . "#sq#,#sq#false#sq#,#sq#" . $fullname . "#sq#,#sq#" . $searchTyp . "#sq#,#sq#ns#sq#,#sq#" . $mahallst . "#sq#,#sq#" . $rtv . "#sq#,#sq##sq#,#sq#" . $dmap . "#sq#,0,0,1,0,0)";

			

				$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);


				$lid=$wpdb->insert_id;
			
				$rtv = strval($rtv) . $lid;

$query="update wp_dlt_files set dcod='" . $rtv . "' where id=" . $lid;
//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);



				

$query = "insert into wp_dlt_user (sid,issecure,dregdate,dfullname,dmail,dpass,dmob,dusn,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#false#sq#,#sq#" . $nowdt . "#sq#,#sq#" . $fullname . "#sq#,#sq#" . $mail . "#sq#,#sq#" . $rtv . "#sq#,#sq#" . $mobile . "#sq#,#sq#" . $mobile . "#sq#,0,0,1,0,0)";

$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);

}else{
	$rtv = "needlogin";
}


			break;

			case "sendRegF":
				//actifCity:data.dactifCity, actifState:data.dactifState, searchTyp: data.dsearchTyp, dfullname: data.fullname, dmobile: data.mobile, dmail: data.mail, mahallst: data.mahal, dmainalay: data.mainalay, dcapacity: data.capacity, dbanacapacity: data.banacapacity, dtoolebar: data.toolebar, dfloor: data.floor, dfloorcont: data.floorcont, drooms: data.rooms, dage: data.age, dfullprice: data.fullprice, drentprice: data.rentprice, descparams: data.descparams, desctxt: data.dfesctxt, dimg1: data.img1, dimgs2: data.imgs2 };

				$rahg = "";//microtime(true) * 10000000;
				$rgy = $_REQUEST['drgy'];
				$rgm = $_REQUEST['drgm'];
				$rgd = $_REQUEST['drgd'];
				$rtv = strval($rgy) . strval($rgm) . strval($rgd);// . $lid;


				$searchTyp=$_REQUEST['searchTyp'];
				$actifCity=$_REQUEST['actifCity'];
				$actifState=$_REQUEST['actifState'];
				$fullname=$_REQUEST['dfullname'];
				$mobile=$_REQUEST['dmobile'];
				$mail=$_REQUEST['dmail'];
				$mahallst=$_REQUEST['mahallst'];
				$mainalay=$_REQUEST['dmainalay'];
				$capacity=$_REQUEST['dcapacity'];
				$banacapacity=$_REQUEST['dbanacapacity'];
				$toolebar=$_REQUEST['dtoolebar'];
				$floor=$_REQUEST['dfloor'];
				$floorcont=$_REQUEST['dfloorcont'];
				$rooms=$_REQUEST['drooms'];
				$age=$_REQUEST['dage'];
				$fullprice=$_REQUEST['dfullprice'];
				$rentprice=$_REQUEST['drentprice'];
				$descparams=$_REQUEST['descparams'];
				$desctxt=$_REQUEST['desctxt'];
				$img1=$_REQUEST['dimg1'];
				$imgs2=$_REQUEST['dimgs2'];
				$ddactifUsage=$_REQUEST['ddactifUsage'];
				$darzegozar=$_REQUEST['darzegozar'];
				$darzeshemelk=$_REQUEST['darzeshemelk'];
				$dsarghofliprice=$_REQUEST['dsarghofliprice'];
				$dtit=$_REQUEST['dtit'];
				$dmap=$_REQUEST['map'];

$dnid=$_REQUEST['nid'];
if( $dnid != "0" ){
	$query="delete from wp_dlt_files where id=" . $dnid;
	$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);
}

				//$dactifUsage=$_REQUEST['actifUsage'];

//nid:data.did, darzegozar: data.arzegozar, darzeshemelk: data.arzeshemelk, dsarghofliprice: data.sarghofliprice,

list($usec, $sec) = explode(" ", microtime());
$ticks = (int)($sec*10000000+$usec*10000000);


				$data0 = explode('nnpp', $imgs2)[0];//'data:image/png;base64,AAAFBfj42Pj4';

$imgdata = base64_decode($data0);

$f = finfo_open();

$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
//$rtv = mime_type

				$ext = ".png";
$has_jpg = (strpos($mime_type, '/jpg') !== false) || (strpos($mime_type, '/jpeg') !== false);
if($has_jpg === true){
	$ext = '.jpg';
}

//list($type, $data) = explode(';', $data);
//list(, $data) = explode(',', $data);
$data = base64_decode($data0);

file_put_contents('/var/www/maxim.shop/hototo/files/' . $ticks . $ext, $data);
				
				$nowdt=date('m/d/Y h:i:s');

				$img1='http://heram.shop/hototo/files/' . $ticks . $ext;
				//$imgs2='';

				$query = "insert into wp_dlt_files (sid,dtitr,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,dmap,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#" . $dtit . "#sq#,#sq##sq#,0,#sq#" . $darzeshemelk . "#sq#,#sq#" . $darzegozar . "#sq#,#sq#" . $dsarghofliprice . "#sq#,#sq#false#sq#,#sq#" . $banacapacity . "#sq#,#sq#" . $toolebar . "#sq#,#sq#" . $desctxt . "#sq#,#sq#" . $descparams . "#sq#,#sq#" . $rentprice . "#sq#,#sq#" . $fullprice . "#sq#,#sq#" . $age . "#sq#,#sq#" . $rooms . "#sq#,#sq#" . $floorcont . "#sq#,#sq#" . $floor . "#sq#,#sq#" . $capacity . "#sq#,#sq#" . $mainalay . "#sq#,#sq#" . $actifState . "#sq#," . $actifCity . ",#sq#" . $mail . "#sq#,#sq#" . $mobile . "#sq#,#sq#" . $fullname . "#sq#,#sq#" . $nowdt . "#sq#,#sq#regnotcheck#sq#,#sq#" . $ddactifUsage . "#sq#,#sq#" . $imgs2 . "#sq#,#sq#" . $img1 . "#sq#,#sq#false#sq#,#sq#" . $fullname . "#sq#,#sq#" . $searchTyp . "#sq#,#sq#ns#sq#,#sq#" . $mahallst . "#sq#,#sq#" . $rtv . "#sq#,#sq##sq#,#sq#" . $dmap . "#sq#,0,0,1,0,0)";

				//$query="insert into wp_dlt_files (sid,moshaver,ajans,arzeshemelk,arzegozar,sarghofliprice,issargofli,banacapacity,toolebar,desctxt,descparams,drentprice,dfullprice,dage,drooms,floorcont,dfloor,dcapacity,mainalay,dstate,dcity,dmail,dmobile,dfullname,dexpir,actif,usagetyp,dimgs2,dimg1,dspecial,downer,dtyp,dcod,mahal,fullprops,mainurl,dmap,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,0,#sq##sq#,#sq##sq#,#sq##sq#,#sq#12/11/2018 5:58:53 PM#sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq#false#sq#,#sq##sq#,#sq##sq#,#sq#ccttt#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,0,0,1,0,0)";


				$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);


				$lid=$wpdb->insert_id;
				/*$query2 = "select id from wp_dlt_files order by id desc LIMIT 1";
				$results = $wpdb->get_results( $query2, OBJECT );
				foreach($results as $fv) {
				    $lid=$fv->id;
				    break;
				 }*/

				/* $query = "update wp_dlt_files set ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzegozar='" . $darzegozar . "' , ";
				 $query = $query . "sarghofliprice='" . $dsarghofliprice . "' , ";
				 $query = $query . "banacapacity='" . $banacapacity . "' , ";
				 $query = $query . "toolebar='" . $toolebar . "' , ";
				 $query = $query . "desctxt='" . $desctxt . "' , ";
				 $query = $query . "descparams='" . $descparams . "' , ";
				 $query = $query . "rentprice='" . $rentprice . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
				 $query = $query . "arzeshemelk='" . $darzeshemelk . "' , ";
*/

				$rtv = strval($rtv) . $lid;

$query="update wp_dlt_files set dcod='" . $rtv . "' where id=" . $lid;
//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);


				//$rtv = $query;
			break;

			case "sendRequestF":
				//var propertiesObject = { api:"sql",cmd:"sendRequestF", searchTyp: data.dsearchTyp, fullname: data.dfullname, mobile: data.dmobile, email: data.demail, 

				$rahg = "";

				$rgy = $_REQUEST['drgy'];
				$rgm = $_REQUEST['drgm'];
				$rgd = $_REQUEST['drgd'];
				$rtv = strval($rgy) . strval($rgm) . strval($rgd);// . $lid;


				$searchTyp=$_REQUEST['searchTyp'];
				$actifCity=$_REQUEST['actifCity'];
				$actifState=$_REQUEST['actifState'];
				$fullname=$_REQUEST['fullname'];
				$mobile=$_REQUEST['mobile'];
				$mail=$_REQUEST['email'];
				$ddactifUsage=$_REQUEST['ddactifUsage'];
				$capacity=$_REQUEST['capacity'];
				$fullprice=$_REQUEST['fullprice'];
				$rentprice=$_REQUEST['rentprice'];
				$desc=$_REQUEST['desc'];
			
				$prc=$fullprice . " - " . $rentprice;

				$query = "insert into wp_dlt_requests (sid,drent,dtyp,dcheck,ddesc,dprice,dmeter,dmail,dtel,dfullname,usagetyp,dstate,dcity,dcode,ownerTbl,ownerRec,isSingle,isExist,isNew) values(62,#sq#" . $rentprice . "#sq#,#sq#" . $searchTyp . "#sq#,#sq#false#sq#,#sq#" . $desc . "#sq#,#sq#" . $prc . "#sq#,#sq#" . $capacity . "#sq#,#sq#" . $mail . "#sq#,#sq#" . $mobile . "#sq#,#sq#" . $fullname . "#sq#,#sq#" . $ddactifUsage . "#sq#,#sq#" . $actifState . "#sq#,#sq#" . $actifCity . "#sq#,#sq#" . $rtv . "#sq#,0,0,1,0,0)";

$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);


				$lid=$wpdb->insert_id;
				

				$rtv = strval($rtv) . $lid;


$query="update wp_dlt_requests set dcode='" . $rtv . "' where id=" . $lid;
//$query=str_replace("#sq#","'",$query);
				$results = $wpdb->query(
						        	$query
								);

				
			break;

			case "getSearch2":
				//var propertiesObject = { api:"sql",cmd:"getSearch2",searchTyp: data.dsearchTyp, actifCity: data.dactifCity, actifStateStr: data.dfiltstateArStr, filtmahalArStr: data.dfiltmahalArStr, minCap: data.dminCap, maxCap: data.dmaxCap, minPrc: data.dminPrc, maxPrc: data.dmaxPrc, minRent: data.dminRent, maxRent: data.dmaxRent };

			$dactifCity=$_REQUEST['actifCity'];
			$dactifStateStr=$_REQUEST['actifStateStr'];
			$dactifStateAr = explode(",", $dactifStateStr);


			$dfiltmahalArStr=$_REQUEST['filtmahalArStr'];
			$dfiltmahalAr = explode(",", $dfiltmahalArStr);

			$dactifUsage=$_REQUEST['actifUsage'];
			$dminCap=$_REQUEST['minCap'];
			$dmaxCap=$_REQUEST['maxCap'];
			$dminPrc=$_REQUEST['minPrc'];
			$dmaxPrc=$_REQUEST['maxPrc'];
			$dminRent=$_REQUEST['minRent'];
			$dmaxRent=$_REQUEST['maxRent'];
			$dsearchTyp=$_REQUEST['searchTyp'];

			$query = "select id,actif, dtitr, dstate , dsearchparams, mahal, SUBSTRING(desctxt, 0, 85) AS desctxt2, dage, dfloor, drooms, TIMESTAMPDIFF(SECOND,STR_TO_DATE(dexpir, '%m/%d/%Y %h:%i:%s %p'),NOW()) AS dexpir2, ajans, dimg1, ROUND ( ( LENGTH(dimgs2) - LENGTH( REPLACE ( dimgs2, 'nnpp', '') ) ) / LENGTH('nnpp') ) AS img2num from wp_dlt_files";
			
			$query = $query . " where (actif = 'ready') and (dtyp='" . $dsearchTyp . "') ";//and (dcity=" . $dactifCity . ") and (usagetyp='" . $dactifUsage . "')";
			$query = $query . "and (dcity=" . $dactifCity . ") ";
			$query = $query . "and (usagetyp='" . $dactifUsage . "') ";
			

			//SELECT ID, Name FROM TableName WHERE Name IN ('Big','Small','Extra')
// (usagetyp='1')  and  (dstate IN ( ))'-1' ))
			
			if (count($dactifStateAr) > 0){
				$dstatever = " (dstate IN (";
				$atcn = 0;
				foreach($dactifStateAr as $value) {
					if($value != ''){

						//$query = $query . " and (dstate='" . $value . "')";	
						$dstatever = $dstatever . "'" . $value . "',";
						$atcn = $atcn + 1;
					}
				}
				$dstatever = $dstatever . " ))";
				if($atcn > 1){
					$query = $query . " and " . $dstatever ;	
				}
			}

			if (count($dfiltmahalAr) > 0){
				$dmahalver = " (mahal IN (";
				$atcn = 0;
				foreach($dfiltmahalAr as $value) {
					if($value != ''){

						//$query = $query . " and (dstate='" . $value . "')";	
						$dmahalver = $dmahalver . "'" . $value . "',";
						$atcn = $atcn + 1;
					}
				}
				$dstatever = $dstatever . " ))";
				if($atcn > 1){
					$query = $query . " and " . $dstatever ;	
				}
			}

			$query = $query . " and (CONVERT(dcapacity, SIGNED INTEGER) >= " . $dminCap . ") and (CONVERT(dcapacity, SIGNED INTEGER) <= " . $dmaxCap . ")";	
			$query = $query . " and (CONVERT(dfullprice, SIGNED INTEGER) >= " . $dminPrc . ") and (CONVERT(dfullprice, SIGNED INTEGER) <= " . $dmaxPrc . ")";	

			if($dsearchTyp == "rent"){
				$query = $query . " and (CONVERT(drentprice, SIGNED INTEGER) >= " . $dminRent . ") and (CONVERT(dcapacity, SIGNED INTEGER) <= " . $dmaxRent . ")";	
			}

			$query = $query . " order by id desc";
			$results = $wpdb->get_results( $query, OBJECT );
			//$rtv = $results; 
			$rtv = json_encode($results);

//$rtv=$query;
			break;
			case "getSearch":
				///cap , city, state, mahal, price, rent, dec-85, age, floor, rooms, date, ajanslogo, img1, imgnum

			//var propertiesObject = { api:"sql",cmd:"getSearch",actifCity: data.dactifCity, actifState: data.dactifState, actifUsage: data.dactifUsage, minCap: data.dminCap, maxCap: data.dmaxCap, minPrc: data.dminPrc, maxPrc: data.dmaxPrc, minRent: data.dminRent };

			$dactifCity=$_REQUEST['actifCity'];
			$dactifState=$_REQUEST['actifState'];
			$dactifUsage=$_REQUEST['actifUsage'];
			$dminCap=$_REQUEST['minCap'];
			$dmaxCap=$_REQUEST['maxCap'];
			$dminPrc=$_REQUEST['minPrc'];
			$dmaxPrc=$_REQUEST['maxPrc'];
			$dminRent=$_REQUEST['minRent'];
			$dmaxRent=$_REQUEST['maxRent'];
			$dsearchTyp=$_REQUEST['searchTyp'];

			

			//id, mahal, desctxt/85, dage, dfloor, drooms, dexpir-now, ajans, dimg1, dimgs2-cont-nnpp

//if($dsearchTyp=="buy")
			//$query = "select id, mahal, SUBSTRING(desctxt, 0, 85) AS desctxt2, dage, dfloor, drooms, TIMESTAMPDIFF(SECOND,STR_TO_DATE(dexpir, '%m/%d/%Y %h:%i:%s %p'),NOW()) AS dexpir2, ajans, dimg1, ROUND ( ( LENGTH(dimgs2) - LENGTH( REPLACE ( dimgs2, 'nnpp', '') ) ) / LENGTH('nnpp') ) AS img2num from wp_dlt_files where (dtyp='" . $dsearchTyp . "') and (dcity='" . $dactifCity . "') and (usagetyp='" . $dactifUsage . "')";
//dstate
$query = "select id, actif, dtitr , dsearchparams, mahal, SUBSTRING(desctxt, 0, 85) AS desctxt2, dage, dfloor, drooms, TIMESTAMPDIFF(SECOND,STR_TO_DATE(dexpir, '%m/%d/%Y %h:%i:%s %p'),NOW()) AS dexpir2, ajans, dimg1, ROUND ( ( LENGTH(dimgs2) - LENGTH( REPLACE ( dimgs2, 'nnpp', '') ) ) / LENGTH('nnpp') ) AS img2num from wp_dlt_files";
			
$query = $query . " where  ((actif = 'ready')) and (dtyp='" . $dsearchTyp . "') ";//and (dcity=" . $dactifCity . ") and (usagetyp='" . $dactifUsage . "')";
$query = $query . "and (dcity=" . $dactifCity . ") ";
$query = $query . "and (usagetyp='" . $dactifUsage . "') ";
//$query = $query . "and (dcity=" . $dactifCity . ") ";

			if($dactifState != "ns"){
				$query = $query . " and (dstate='" . $dactifState . "')";	
			}
//STRCMP(string1, string2)
			//$query = $query . " and (STRCMP(dcapacity, '" . $dminCap . "') >= 1) and (STRCMP(dcapacity, '" . $dmaxCap . "') <= 0)";	
			
			$query = $query . " and (CONVERT(dcapacity, SIGNED INTEGER) >= " . $dminCap . ") and (CONVERT(dcapacity, SIGNED INTEGER) <= " . $dmaxCap . ")";	
			$query = $query . " and (CONVERT(dfullprice, SIGNED INTEGER) >= " . $dminPrc . ") and (CONVERT(dfullprice, SIGNED INTEGER) <= " . $dmaxPrc . ")";	
			//$query = $query . " and (STRCMP(dfullprice, '" . $dminPrc . "') >= 1) and (STRCMP(dfullprice, '" . $dmaxPrc . "') <= 0)";	
			//$query = $query . " and (dfullprice >= '" . $dminPrc . "') and (dfullprice <= '" . $dmaxPrc . "')";	

			if($dsearchTyp == "rent"){
				$query = $query . " and (CONVERT(drentprice, SIGNED INTEGER) >= " . $dminRent . ") and (CONVERT(dcapacity, SIGNED INTEGER) <= " . $dmaxRent . ")";	
				//$query = $query . " and (drentprice >= '" . $dminRent . "') and (drentprice <= '" . $dmaxRent . "')";
			//	$query = $query . " and (STRCMP(drentprice, '" . $dminRent . "') >= 1) and (STRCMP(drentprice, '" . $dmaxRent . "') <= 0)";		
			}
/*			*/
			$query = $query . " order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);
//$rtv=$query;
//if($dsearchTyp)

//desctxt2,dexpir2,img2num
				//SELECT TIMESTAMPDIFF(SECOND,STR_TO_DATE(dexpir, '%m/%d/%Y %h:%i:%s %p'),NOW()) AS ddif from post_statistics
//ROUND ( ( LENGTH(dimgs2) - LENGTH( REPLACE ( dimgs2, "nnpp", "") ) ) / LENGTH("nnpp") ) AS img2num
//SUBSTRING("desctxt", 0, 85) AS desctxt2
			
			break;

//cmd:"getItem",did: data.fid };
			case "getItem":
				$fid=$_REQUEST['did'];	
				$query = "select *,TIMESTAMPDIFF(SECOND,STR_TO_DATE(dexpir, '%m/%d/%Y %h:%i:%s %p'),NOW()) AS dexpir2 from wp_dlt_files where id=" . $fid . " order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);
			

			break;

			case "getFiles":

				$dcity=$_REQUEST['city'];
				//$query = "select id,dfullprice,drentprice,dage,drooms,dfloor,dcapacity,mainalay,dstate,dcity,dmobile,dfullname,dimg1 from wp_dlt_files";// where dcity=" . $dcity . "";
				$query = "select id,dexpir,dfullprice,drentprice,dcapacity,dstate,dcity,usagetyp,dtyp from wp_dlt_files where (dcity=" . $dcity . ") and ((actif = 'ready')) order by id desc";
				$results = $wpdb->get_results( $query, OBJECT );
				//$rtv = $results; 
				$rtv = json_encode($results);

			break;

			case "registerme":

				$dus=$_REQUEST['dus'];
				$dps=$_REQUEST['dps'];
				$dtkn="";
				$dsys="";


				//insert into wp_ndr_otherdevice (sid,dus,dsys,dtkn,ddate,ownerTbl,ownerRec,isSingle,isExist,isNew) values(58,09128116580,#sq#android#sq#,#sq#xxxxxx#sq#,#sq#10/19/2018 2:40:54 AM#sq#,0,0,1,0,0)

				//insert into wp_ndr_user (sid,dname,diemob,diemail,diepass,dlastlog,ddate,dsys,dtokn,ownerTbl,ownerRec,isSingle,isExist,isNew) values(58,09128116580,09128116580,#sq#kevin@mail.com#sq#,123,#sq#10/19/2018 2:22:32 AM#sq#,#sq#10/19/2018 2:22:32 AM#sq#,#sq#android#sq#,#sq#xxxxxxx#sq#,0,0,1,0,0)


				//select
				$query = "";
				$tid = 0;
				$pos = strrpos($dus, "@");
				if ($pos === false) { 
					$query = "select * from wp_ndr_user where (diemob='" . $dus . "' and diepass='" . $dps . "')";
				}else{
					$query = "select * from wp_ndr_user where (diemail='" . $dus . "' and diepass='" . $dps . "')";
				}
				//$query = 'select * from wp_ndr_user';
				$results = $wpdb->get_results( $query, OBJECT );
				foreach($results as $fv) {
				    $tid=$fv->id;
				    break;
				}
				if ($tid === 0) { 
					if ($pos === false) { 
						$query = "select * from wp_ndr_user where diemob='" . $dus . "'";// and diepass='" . $dps . "'";
					}else{
						$query = "select * from wp_ndr_user where diemail='" . $dus . "'";//" and diepass='" . $dps . "'";
					}
					$results = $wpdb->get_results( $query, OBJECT );
					foreach($results as $fv) {
					    $tid=$fv->id;
					    break;
					}
					if ($tid === 0) { 
					//	$rtv="badlog1";
					//}else{
						if ($pos === false) { 
							$query = "insert into wp_ndr_user (sid,dname,diemob,diemail,diepass,dlastlog,ddate,dsys,dtokn,ownerTbl,ownerRec,isSingle,isExist,isNew) values(58,'" . "newuser" ."','" . $dus . "','mail','" . $dps . "','" . $dnow . "','" . $dnow . "','". $dsys . "','" . $dtkn . "',0,0,1,0,0)";
						}else{
							$query = "insert into wp_ndr_user (sid,dname,diemob,diemail,diepass,dlastlog,ddate,dsys,dtokn,ownerTbl,ownerRec,isSingle,isExist,isNew) values(58,'" . "newuser" ."','" . "mob" . "','" . $dus . "','" . $dps . "','" . $dnow . "','" . $dnow . "','". $dsys . "','" . $dtkn . "',0,0,1,0,0)";
						}
						//$query = "select * from wp_ndr_user diemob='" . $dus . "' and diepass='" . $dps . "'";
						//run	
						$results = $wpdb->query(
				        	$query
						);
						$rtv="regdown";
					}else{
					$rtv="badlog";	
					}
				}else{
					//$query = "select * from wp_ndr_user diemail='" . $dus . "' and diepass='" . $dps . "'";
					$rtv="logedin";
				}

			break;

		}

	break;

}

echo $rtv;

?>